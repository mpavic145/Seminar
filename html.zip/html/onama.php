﻿<!--     Isključivanje izvještaja o pogreškama
         Pokretanje ili nastavljanje sesije
		 Dohvaćivanje i provjera postavki jezika te spremanje u session varijablu -->
<?php
        error_reporting(0);
        session_start();

        $vrijednost=$_GET["lan"];
        
        if(is_numeric($vrijednost))
        {
                if($vrijednost == 1 || $vrijednost==2)
                $_SESSION["lang_id"]=$vrijednost;
        }       
?>
<!DOCTYPE html>
<html>
  <head>
    <!--     Vanjski css -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="css/main.css" />
	<!--     Meta elementi -->
	<meta charset="UTF-8" />
    <meta name="generator" content="HTML Tidy for HTML5 (experimental) for Windows https://github.com/w3c/tidy-html5/tree/c63cc39" />
    <meta name="keywords" content="Kazalište, Theatre, Theater, Predstave, Shows, Zabava, Fun, Druženje, Socialising" />
    <meta name="author" content="Marko Pavić" />
    <meta name="description" content="Kazalište Nillin - kazalište za sve! / Theatre Nillin - theater for all!" />
	<!--     Naslov -->
    <title>Kazalište Nillin</title>
  </head>
  <body>
  <header>
    <!--     Logo i navigacija -->
    <div class="container">
      <div id="logo">
        <a href="home.php">
          <img src="img/logo.jpg" width="100" alt="logo" />
        </a>
      </div>
      <div class="navbar">
        <div class="navbar-inner">
          <ul class="nav">
            <li class="active">
              <a href="home.php">Home</a>
            </li>
            <li class="active">
              <a href="predstave.php">Predstave / Shows</a>
            </li>
            <li class="active">
              <a href="onama.php">O nama / About us</a>
            </li>
            <li class="active">
              <a href="kontakt.html">Kontakt / Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </header>
  <hr />
  <!--     Jezik -->
  <div class="container">
  <a href='onama.php?lan=1'>
    <img src="img/Croatian-Flag-64.png" width="25" alt="cro_language"
    style="margin-left:880px;margin-top:20px;position:absolute;" />
  </a> 
  <a href='onama.php?lan=2'>
    <img src="img/United-Kingdo-icon.png" width="25" alt="eng_language"
    style="margin-left:914px;margin-top:21px;position:absolute;" />
  </a>
  <div id="opis">
		<!--     Dohvat informcija o kazalištu iz baze ovisno o jeziku -->
		<?php
                                                                                            
                                                    $servername = "localhost";
                                                    $username = "root";
                                                    $password = "root";
                                                    $dbname = "seminar";
                                                    
                                                    if(isset($_SESSION["lang_id"]))
                                                    $emp_id=$_SESSION["lang_id"];
                                                    else 
                                                    $emp_id=1;

                                                            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
                                                            // set the PDO error mode to exception
                                                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                    
                                                            $sth = $conn->prepare("SELECT Naziv, O_nama FROM onama WHERE ID= :empid");
                                                            $sth->bindParam(':empid', $emp_id, PDO::PARAM_INT);
                                                            $sth->execute();
                                                            $row = $sth->fetch();
                                                            echo '<h3>'.$row['Naziv'].'</h3>'.'<br>';
                                                            echo  wordwrap($row['O_nama'], 63, "<br>\n");

                                                            $conn = null;
                                                            ?>
  </div>
  <br />
  <br />
  <!--     Karta -->
  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2781.8242794889757!2d15.941462315084225!3d45.79474801934784!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4765d6bc263498f1%3A0x428c6c5a3be89691!2sGRADSKO+KAZALI%C5%A0TE+TRE%C5%A0NJA!5e0!3m2!1shr!2shr!4v1458569897002"
  width="940" height="500" style="border:0" allowfullscreen=""></iframe></div>
  <hr />
  <footer>
    <!--     Izradio i povratak na vrh -->
    <div class="container">
      <pre>Izradio / Made by: Marko Pavić   Kontakt / Contact: mpavic@tvz.hr                                                            <a href="#logo"><img src="img/arrow.jpg" width="30" alt="back_to_the_beginning" /></a></pre>
    </div>
  </footer>
  <!--     Vanjski js  -->
  <script src="http://code.jquery.com/jquery.js"></script> 
  <script src="js/bootstrap.js"></script></body>
</html>
