function provjera()
{
	var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
	var iChar  = "!#$%^&*()+=[]\\\';,/{}|\":<>?";
	var iCha   = "#$^&*+=[]\\\';/{}|\"<>";
	var iCh    = "@";
	var x=0;

	for (var i = 0; i < document.upit.inputName.value.length; i++) {
		if (iChars.indexOf(document.upit.inputName.value.charAt(i)) != -1) {
			alert ("Your name has special characters. \nThese are not allowed.\n Please remove them and try again.");
			return false;
		}
	}
	
	for (var i = 0; i < document.upit.inputEmail.value.length; i++) {
		if (iChar.indexOf(document.upit.inputEmail.value.charAt(i)) != -1) {
			alert ("Your email has special characters. \nThese are not allowed.\n Please remove them and try again.");
			return false;
		}
	}
	
	for (var i = 0; i < document.upit.Textarea.value.length; i++) {
		if (iCha.indexOf(document.upit.Textarea.value.charAt(i)) != -1) {
			alert ("Your question has special characters. \nThese are not allowed.\n Please remove them and try again.");
			return false;
		}
	}
	
	if ( document.getElementById("inputName").value.length < 3 || document.getElementById("inputName").value.length > 30 )
			{
				document.getElementById("inputName").style.border="2px solid red";
				document.getElementById("poruka0").style.display="initial";
				document.getElementById("poruka0").innerHTML="Ime sadrži premalo ili previše znakova!";
				x++;
			}
	else 
		{
			document.getElementById("inputName").style.border="";
			document.getElementById("poruka0").style.display="none";
			
		}
	
	if ( document.getElementById("inputEmail").value.length < 5 || document.getElementById("inputEmail").value.length > 30 )
			{
				document.getElementById("inputEmail").style.border="2px solid red";
				document.getElementById("poruka1").style.display="initial";
				document.getElementById("poruka1").innerHTML="Email sadrži premalo ili previše znakova!";
				x++;
			}
	else 
		{
			document.getElementById("inputEmail").style.border="";
			document.getElementById("poruka1").style.display="none";
		}
	
	if ( document.getElementById("Textarea").value.length <10 || document.getElementById("Textarea").value.length > 300 )
			{
				document.getElementById("Textarea").style.border="2px solid red";
				document.getElementById("poruka2").style.display="initial";
				document.getElementById("poruka2").innerHTML="Upit sadrži premalo ili previše znakova!";
				x++;
			}
	else 
		{
			document.getElementById("Textarea").style.border="";
			document.getElementById("poruka2").style.display="none";
		}
			
	if(x!=0) return false;		
	else     return true;

}
