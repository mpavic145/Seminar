<!--     Isključivanje izvještaja o pogreškama
         Pokretanje ili nastavljanje sesije -->
<?php
        error_reporting(0);
        session_start();
?>
<!DOCTYPE html>
<html>
  <head>
    <!--     Vanjski css -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="css/main.css" />
    <!--     Meta elementi -->
    <meta charset="UTF-8" />
    <meta name="generator" content="HTML Tidy for HTML5 (experimental) for Windows https://github.com/w3c/tidy-html5/tree/c63cc39" />
    <meta name="keywords" content="Kazalište, Theatre, Theater, Predstave, Shows, Zabava, Fun, Druženje, Socialising" />
    <meta name="author" content="Marko Pavić" />
    <meta name="description" content="Kazalište Nillin - kazalište za sve! / Theatre Nillin - theater for all!" />
    <meta http-equiv="refresh" content="5;url=home.php" />
    <!--     Naslov -->
    <title>Kazalište Nillin</title>
  </head>
  <body>
  <header>
    <!--     Logo i navigacija -->
    <div class="container">
      <div id="logo">
        <a href="home.php">
          <img src="img/logo.jpg" width="100" alt="logo" />
        </a>
      </div>
      <div class="navbar">
        <div class="navbar-inner">
          <ul class="nav">
            <li class="active">
              <a href="home.php">Home</a>
            </li>
            <li class="active">
              <a href="predstave.php">Predstave / Shows</a>
            </li>
            <li class="active">
              <a href="onama.php">O nama / About us</a>
            </li>
            <li class="active">
              <a href="kontakt.html">Kontakt / Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </header>
  <hr />
  <!--   Zahvala na poruci -->
  <div class="container">
    <?php


                                        if(isset($_SESSION["lang_id"]))
                                        {
                                                if($_SESSION["lang_id"]==1)
                                                {
                                                        echo "Zahvaljujemo na vašoj poruci! Biti ćete preusmjereni na početnu stranicu za 5 sekundi.<br/ >";
                                                        echo "Ukoliko Vas ne preusmjerava ili Vam se ne da čekati, stisnite <a href=\"home.php\">Home</a>";
                                                }
                                                
                                                else
                                                {
                                                        echo "Thank you for your message! You will be redirected to the home page in 5 seconds.<br/ >";
                                                        echo "If You are not redirected or You do not want to wait, press <a href=\"home.php\">Home</a>";
                                                }
                                                
                                        }
                                        
                                        else 
                                        {
                                                echo "Zahvaljujemo na vašoj poruci! Biti ćete preusmjereni na početnu stranicu za 5 sekundi.<br/ >";
                                                echo "Ukoliko Vas ne preusmjerava ili Vam se ne da čekati, stisnite <a href=\"home.php\">Home</a>";
                                        }
                                        
                                        ?>
    <!--     Slanje poruke u bazu -->
    <?php           

                                                $servername = "localhost";
                                                $username = "root";
                                                $password = "root";
                                                $dbname = "seminar";
                                                
                                                        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
                                                        // set the PDO error mode to exception
                                                        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                                        
                                                        $stmt = $conn->prepare("INSERT INTO upit (Ime, Email, Upit) VALUES (:ime, :email, :upit)");
                                                        $stmt->bindParam(':ime', $ime);
                                                        $stmt->bindParam(':email', $email);
                                                        $stmt->bindParam(':upit', $upit);
                                                        
                                                        
                                                                                                                        
                                                        $ime=$_POST["inputName"];
                                                        $email=$_POST["inputEmail"];
                                                        $upit=$_POST["Textarea"];

                                                        $stmt->execute();
                                                        
                                                        $conn = null;
                                                                                        
                                                ?>
  </div>
  <!--     Izradio i povratak na vrh -->
  <footer>
    <div class="container">
      <pre>Izradio / Made by: Marko Pavić   Kontakt / Contact: mpavic@tvz.hr                                                            <a href="#logo"><img src="img/arrow.jpg" width="30" alt="back_to_the_beginning" /> </a></pre>
    </div>
  </footer>
  <!--     Vanjski js  -->
  <script src="http://code.jquery.com/jquery.js"></script> 
  <script src="js/bootstrap.js"></script></body>
</html>
