﻿<!--     Isključivanje izvještaja o pogreškama
         Pokretanje ili nastavljanje sesije
		 Dohvaćivanje i provjera postavki jezika te spremanje u session varijablu -->
<?php
        error_reporting(0);
        session_start();
        
        $vrijednost=$_GET["lan"];
        
        if(is_numeric($vrijednost))
        {
                if($vrijednost == 1 || $vrijednost==2)
                $_SESSION["lang_id"]=$vrijednost;
        }       
?>
<!DOCTYPE html>
<html>
  <head>
    <!--     Vanjski css -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="css/main.css" />
	<!--     Meta elementi -->
    <meta charset="UTF-8" />
    <meta name="generator" content="HTML Tidy for HTML5 (experimental) for Windows https://github.com/w3c/tidy-html5/tree/c63cc39" />
    <meta name="keywords" content="Kazalište, Theatre, Theater, Predstave, Shows, Zabava, Fun, Druženje, Socialising" />
    <meta name="author" content="Marko Pavić" />
    <meta name="description" content="Kazalište Nillin - kazalište za sve! / Theatre Nillin - theater for all!" />
	<!--     Naslov -->
    <title>Kazalište Nillin</title>
  </head>
  <body>
  <header>
    <!--     Logo i navigacija -->
    <div class="container">
      <div id="logo">
        <a href="home.php">
          <img src="img/logo.jpg" width="100" alt="logo" />
        </a>
      </div>
      <div class="navbar">
        <div class="navbar-inner">
          <ul class="nav">
            <li class="active">
              <a href="home.php">Home</a>
            </li>
            <li class="active">
              <a href="predstave.php">Predstave / Shows</a>
            </li>
            <li class="active">
              <a href="onama.php">O nama / About us</a>
            </li>
            <li class="active">
              <a href="kontakt.html">Kontakt / Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </header>
  <hr />
  <!--     Jezik -->
  <div class="container">
  <a href='labude_jezero.php?lan=1'>
    <img src="img/Croatian-Flag-64.png" width="25" alt="cro_language"
    style="margin-left:880px;margin-top:20px;position:absolute;" />
  </a> 
  <a href='labude_jezero.php?lan=2'>
    <img src="img/United-Kingdo-icon.png" width="25" alt="eng_language"
    style="margin-left:914px;margin-top:21px;position:absolute;" />
  </a> 
		<!--     Dohvat informcija o predstavi iz baze ovisno o jeziku -->
		<?php
                          $servername = "localhost";
                          $username = "root";
                          $password = "root";
                          $dbname = "seminar";
                          $id=4;
                          
                          if(isset($_SESSION["lang_id"]))
                          $emp_id=$_SESSION["lang_id"];
                          else 
                          $emp_id=1;
                  
                          

                                  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
                                  // set the PDO error mode to exception
                                  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                  
                                  if($emp_id==1)
                                  {
                                          $sth = $conn->prepare("SELECT Naziv, Opis_hr, Radnja_hr, Uloge_hr FROM predstave WHERE ID= :id");
                                          $sth->bindParam(':id', $id, PDO::PARAM_INT);
                                          $sth->execute();
                                          $row = $sth->fetch();
                                          echo '<h3>'.$row['Naziv'].'</h3>'.'<br>'.'<br>';
                                          echo '<pre>'.$row['Opis_hr'].'</pre>'.'<br>';
                                          echo '<pre>'.$row['Radnja_hr'].'</pre>'.'<br>';
                                          echo '<pre>'.$row['Uloge_hr'].'</pre>'.'<br>';

                                          $conn = null;
                                          
                                  }
                                  else
                                  {
                                          $sth = $conn->prepare("SELECT Naziv_en, Opis_en, Radnja_en, Uloge_en FROM predstave WHERE ID= :id");
                                          $sth->bindParam(':id', $id, PDO::PARAM_INT);
                                          $sth->execute();
                                          $row = $sth->fetch();
                                          echo '<h3>'.$row['Naziv_en'].'</h3>'.'<br>'.'<br>';
                                          echo '<pre>'.$row['Opis_en'].'</pre>'.'<br>';
                                          echo '<pre>'.$row['Radnja_en'].'</pre>'.'<br>';
                                          echo '<pre>'.$row['Uloge_en'].'</pre>'.'<br>';
                                          
                                          $conn = null;
                                          
                                  }

                                  ?>
  <!--     Slike -->
  <div class="row">
    <div class="col-sm-6 col-md-3">
      <a href="img/labjezero.jpg" class="thumbnail">
        <img src="img/labjezero.jpg" alt="lab_jezero" />
      </a>
    </div>
    <div class="col-sm-6 col-md-3">
      <a href="img/labjezero1.jpg" class="thumbnail">
        <img src="img/labjezero1.jpg" alt="lab_jezero1" />
      </a>
    </div>
    <div class="col-sm-6 col-md-3">
      <a href="img/labjezero2.jpg" class="thumbnail">
        <img src="img/labjezero2.jpg" alt="lab_jezero2" />
      </a>
    </div>
  </div></div>
  <hr />
  <footer>
    <!--     Izradio i povratak na vrh -->
    <div class="container">
      <pre>Izradio / Made by: Marko Pavić   Kontakt / Contact: mpavic@tvz.hr                                                            <a href="#logo"><img src="img/arrow.jpg" width="30" alt="back_to_the_beginning" /></a></pre>
    </div>
  </footer>
  <!--     Vanjski js  -->
  <script src="http://code.jquery.com/jquery.js"></script> 
  <script src="js/bootstrap.js"></script></body>
</html>
